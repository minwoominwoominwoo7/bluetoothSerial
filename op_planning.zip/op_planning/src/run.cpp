#include <planning.h>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "custom_interfacing");
    ros::NodeHandle node_handle;
    ros::AsyncSpinner spinner(2);
    spinner.start();

    if(argc != 2)
    {
        ROS_INFO(" ");
        ROS_INFO("\tUsage:");
        ROS_INFO(" ");
        ROS_INFO("\trosrun planning run  n");
        return 1;
    }

    my_planning::MyPlanningClass my_planning_;

    int selection = atoi(argv[1]);
    geometry_msgs::Pose target_pose1;
    tf2::Quaternion quat_tf;
    geometry_msgs::Quaternion quat_msg ;
    std::vector<double> joint_positions; 

    //my_planning_.addGround();
    switch(selection)
    {   
        joint_positions.clear();
        my_planning_.resetValues();
        case 1:{
            //pose control             
            target_pose1.position.x = 0.5;
            target_pose1.position.y = 0.5;
            target_pose1.position.z = 0.5; 
            quat_tf.setRPY(1.57, 0, 0); //roll,pitch,yaw            
            //tf2::convert(quat_msg , quat_tf);
            quat_msg = tf2::toMsg(quat_tf);
            target_pose1.orientation = quat_msg;
            my_planning_.goToPoseGoal(target_pose1);
            break;
        }
        case 2:
            //position control 
            target_pose1.position.x = 0.5;
            target_pose1.position.y = 0.0;
            target_pose1.position.z = 0.5;            
            my_planning_.goToPositionGoal(target_pose1);
            break;

        case 3:
            //joint control               
            joint_positions.push_back(0);   //elbow_joint
            joint_positions.push_back(0);   //shoulder_lift_joint
            joint_positions.push_back(0);   //shoulder_pan_joint
            joint_positions.push_back(0);   //wrist_1_joint
            joint_positions.push_back(0);   //wrist_2_joint
            joint_positions.push_back(0);   //wrist_3_joint 
            my_planning_.goToJointState(joint_positions);

            break;

        case 4:
            my_planning_.getPose();  
            break;    
        case 5:
            my_planning_.getJoint(); 
            break; 

        case 6:
            //waypoint control 
            my_planning_.cartesianPath();
            break;        

        case 7:
            my_planning_.addObjects();
            break;
        case 8:
            my_planning_.removeObjects();
            break;   
        case 9:
            my_planning_.addGround();
            break;      
        case 10:
            my_planning_.removeGround();
            break;                                         
    }


    spinner.stop();
    return 0;
}