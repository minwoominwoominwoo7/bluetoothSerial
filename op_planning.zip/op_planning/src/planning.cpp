#include <planning.h>
#include <string>

namespace my_planning
{
 
         void MyPlanningClass::goToPoseGoal(geometry_msgs::Pose pose)
        {
            ros::AsyncSpinner spinner(1);
            spinner.start();

            move_group.setPoseTarget(pose);
            //move_group.setMaxVelocityScalingFactor(1);
            //move_group.setMaxAccelerationScalingFactor(1);
            //move_group.setGoalTolerance(1);            
            ros::Duration(0.5).sleep();
            bool success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            
            if(!success) //execute
                throw std::runtime_error("No plan found");

            move_group.move(); //blocking
            spinner.stop(); 
        }        


        void MyPlanningClass::goToPositionGoal(geometry_msgs::Pose pose)
        {
            ros::AsyncSpinner spinner(1);
            spinner.start();
            move_group.setPositionTarget(pose.position.x ,pose.position.y ,pose.position.z);
            //move_group.setMaxVelocityScalingFactor(1);
            //move_group.setMaxAccelerationScalingFactor(1);
            //move_group.setGoalTolerance(1);            
            ros::Duration(0.5).sleep();
            bool success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            
            if(!success) //execute
                throw std::runtime_error("No plan found");

            move_group.move(); //blocking

            spinner.stop(); 

        }         

        void MyPlanningClass::goToJointState( std::vector<double> joint_positions )
        {
            ros::AsyncSpinner spinner(1);
            spinner.start();            
            /*robot_state::RobotState current_state = *move_group.getCurrentState();
            std::vector<double> joint_positions;
            joint_model_group = current_state.getJointModelGroup(PLANNING_GROUP);
            current_state.copyJointGroupPositions(joint_model_group, joint_positions);

            joint_positions[0] = -1.0;
            joint_positions[3] = 0.7;*/

            move_group.setJointValueTarget(joint_positions);
            bool success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            if(!success)
                throw std::runtime_error("No plan found");

            move_group.move(); //blocking
            spinner.stop();  
        }        
        
        void MyPlanningClass::getPose()
        {
            ros::AsyncSpinner spinner(1);
            spinner.start();
            geometry_msgs::PoseStamped current_pose = move_group.getCurrentPose();
            tf::Quaternion q(
                current_pose.pose.orientation.x,
                current_pose.pose.orientation.y,
                current_pose.pose.orientation.z,
                current_pose.pose.orientation.w); 
            tf::Matrix3x3 m(q);      
            double roll, pitch, yaw;  
            m.getRPY(roll, pitch, yaw);       
            ROS_ERROR("point value x %.2f y %.2f z %.2f roll %.2f  picth %.2f  yaw  %.2f ", current_pose.pose.position.x,  current_pose.pose.position.y 
                       ,  current_pose.pose.position.z , roll, pitch, yaw);
            spinner.stop();           
        }  

        void MyPlanningClass::getJoint()
        {   
            ros::AsyncSpinner spinner(1);
            spinner.start();
            const std::vector<std::string> &joint_names = move_group.getJointNames();
            std::vector<double> joint_values = move_group.getCurrentJointValues();

            for (std::size_t i = 0; i < joint_names.size(); i++)
            {
                //res.joint_position.joint_name.push_back(joint_names[i]);
                //res.joint_position.position.push_back(joint_values[i]);
                //ROS_ERROR("joint value %.2f  name %s ", joint_names[i], joint_values[i]);
                ROS_ERROR("joint value %.2f  name %s ", joint_names[i], joint_values[i]);

            }
            spinner.stop();
        }        
#if 1
        void MyPlanningClass::cartesianPath()
        {
            std::vector<geometry_msgs::Pose> waypoints;
            waypoints.push_back(target_pose1);
 
            geometry_msgs::Pose target_pose2 = target_pose1;
 
            target_pose2.position.z -= 0.2;
            waypoints.push_back(target_pose2);
 
            target_pose2.position.y -= 0.2;
            waypoints.push_back(target_pose2);
 
            target_pose2.position.z += 0.2;
            target_pose2.position.y += 0.2;
            target_pose2.position.x -= 0.2;
            waypoints.push_back(target_pose2);
 
            //move_group.setMaxVelocityScalingFactor(0.1);
 
            // We want the Cartesian path to be interpolated at a resolution of 1 cm
            // which is why we will specify 0.01 as the max step in Cartesian
            // translation.  We will specify the jump threshold as 0.0, effectively disabling it.
            // Warning - disabling the jump threshold while operating real hardware can cause
            // large unpredictable motions of redundant joints and could be a safety issue
            moveit_msgs::RobotTrajectory trajectory;
            const double jump_threshold = 0.0;
            const double eef_step = 0.01;
            double fraction = move_group.computeCartesianPath(waypoints, eef_step, jump_threshold, trajectory);

            bool success ;
            moveit::planning_interface::MoveGroupInterface::Plan my_plan;
            success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            move_group.move();

            move_group.move();
            ROS_INFO_STREAM("Percentage of path followed: " << fraction);
        }
#endif

#if 0
        void MyPlanningClass::cartesianPath()
        {
            ros::AsyncSpinner spinner(1);
            spinner.start();

            /*static const std::string PLANNING_GROUP = PLANNING_GROUP;
            moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);
            moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

            const robot_state::JointModelGroup* joint_model_group =
                move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);*/

            std::vector<geometry_msgs::Pose> waypoints;

            geometry_msgs::Pose target_pose1;
            // target_pose1.orientation.w = 1.0;
            target_pose1.position.x = 0.5;
            target_pose1.position.y = 0.2;
            target_pose1.position.z = 0.5;

            tf2::Quaternion q_target;
            q_target.setRotation(tf2::Vector3(0, 1, 0), M_PI/2.0);

            target_pose1.orientation.x = q_target.x();
            target_pose1.orientation.y = q_target.y();
            target_pose1.orientation.z = q_target.z();
            target_pose1.orientation.w = q_target.w();

            bool success ;
            /*move_group.setPoseTarget(target_pose1);

            moveit::planning_interface::MoveGroupInterface::Plan my_plan;
            success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            move_group.move();*/

            ROS_INFO_STREAM("finisht first move");

            waypoints.push_back(target_pose1);

            target_pose1.position.y = 0.0;
            waypoints.push_back(target_pose1);  // right

            target_pose1.position.y = -0.2;
            waypoints.push_back(target_pose1);  // up
           
            //target_pose1.position.y += 0.2;
            //waypoints.push_back(target_pose1);  // left

            move_group.setMaxVelocityScalingFactor(0.1);

            moveit_msgs::RobotTrajectory trajectory;
            const double jump_threshold = 0.0;
            const double eef_step = 0.01;
            double fraction = move_group.computeCartesianPath(waypoints, eef_step, jump_threshold, trajectory);
            ROS_INFO_NAMED("tutorial", "Visualizing plan 4 (Cartesian path) (%.2f%% acheived)", fraction * 100.0);
            ros::Duration(0.5).sleep();
            success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
            
            if(!success) //execute
                throw std::runtime_error("No plan found");
            move_group.move();
            spinner.stop();
        }
#endif

        void MyPlanningClass::resetValues()
        {
            //set the start state and operational speed
            move_group.setStartStateToCurrentState();
            move_group.setMaxVelocityScalingFactor(1.0);
        }

         void MyPlanningClass::makeBox(std::string blk_name, double *pose)
         {
             moveit_msgs::CollisionObject box;
            //set the relative frame
            box.header.frame_id = move_group.getPlanningFrame();
            box.id = blk_name;

            shape_msgs::SolidPrimitive primitive;
            primitive.type = primitive.BOX;
            primitive.dimensions.resize(3);
            primitive.dimensions[0] = 0.2;
            primitive.dimensions[1] = 0.2;
            primitive.dimensions[2] = 1.0;

            geometry_msgs::Pose box_pose;
            box_pose.orientation.w = 1.0;
            box_pose.position.x = pose[0];
            box_pose.position.y = pose[1];
            box_pose.position.z = pose[2];

            box.primitives.push_back(primitive);
            box.primitive_poses.push_back(box_pose);
            box.operation = box.ADD;

            std::vector<moveit_msgs::CollisionObject> collisionObjects;
            collisionObjects.push_back(box);
            ros::Duration(2).sleep();
            virtual_world.addCollisionObjects(collisionObjects);
            ROS_INFO_STREAM("Added: " << blk_name);
         }

        void MyPlanningClass::addObjects()
        {
            double box_pose1[3] = {0.60, -0.67, 0.0,};
            makeBox("block_1", box_pose1);

            double box_pose2[3] = {0.0, 0.77, 0.0,};
            makeBox("block_2", box_pose2);
        }

        void MyPlanningClass::addGround()
        {
             moveit_msgs::CollisionObject box;
            //set the relative frame
            box.header.frame_id = move_group.getPlanningFrame();
            box.id = "Ground";

            shape_msgs::SolidPrimitive primitive;
            primitive.type = primitive.BOX;
            primitive.dimensions.resize(3);
            primitive.dimensions[0] = 3;
            primitive.dimensions[1] = 3;
            primitive.dimensions[2] = 0.1;

            geometry_msgs::Pose box_pose;
            box_pose.orientation.w = 1.0;
            box_pose.position.x = 0;
            box_pose.position.y = 0;
            box_pose.position.z = -0.1;

            box.primitives.push_back(primitive);
            box.primitive_poses.push_back(box_pose);
            box.operation = box.ADD;

            std::vector<moveit_msgs::CollisionObject> collisionObjects;
            collisionObjects.push_back(box);
            ros::Duration(2).sleep();
            virtual_world.addCollisionObjects(collisionObjects);
            ROS_INFO_STREAM("Added: Ground");
        }        

        void MyPlanningClass::removeObjects()
        {
            std::vector<std::string> object_ids;
            object_ids.push_back("block_1");
            object_ids.push_back("block_2");
            ros::Duration(2).sleep();
            virtual_world.removeCollisionObjects(object_ids);
            
            /*virtual_world.removeCollisionObjects(object_ids);
            ros::Duration(2).sleep();
            virtual_world.removeCollisionObjects(object_ids);*/
        }

        void MyPlanningClass::removeGround()
        {
            std::vector<std::string> object_ids;
            object_ids.push_back("Ground");
            ros::Duration(2).sleep();
            virtual_world.removeCollisionObjects(object_ids);
            
            /*virtual_world.removeCollisionObjects(object_ids);
            ros::Duration(2).sleep();
            virtual_world.removeCollisionObjects(object_ids);*/
        }

}