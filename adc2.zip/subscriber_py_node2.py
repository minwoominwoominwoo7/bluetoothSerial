#!/usr/bin/env python
import os
import rospy
from std_msgs.msg import String, UInt16
from rosserial_arduino.msg import Adc

pub = rospy.Publisher('buzzer_on', UInt16, queue_size=10)
def callback(data):
    rospy.loginfo("recieve data %d and send data %d ", data.adc0 , data.adc0)
    if data.adc0 > 0.5 :
        pub.publish(1)
    else :
        pub.publish(0)
    
def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("adc", Adc, callback)
    rospy.loginfo("adc")

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()