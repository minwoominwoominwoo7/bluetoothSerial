실행 명령어 
1. 아두이노를 연결한다. 
2. 피씨에서 아래 순으로 실행 
3. roscore 
4. rosrun rosserial_arduino serial_node.py _port:=/dev/ttyACM0
5. python subscriber_py_node2.py

주의 사항

- 아두이노 코드에 Serial.println 사용하면 로스 시리어 동작 안함. 
